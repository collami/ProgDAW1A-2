package Ejercicio2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author infor14
 */
public class Ejercicio2 {

    public static void main(String[] args) {
        try {
            tratarFichero();
        } catch (MiExcepcion ex) {
            System.out.println("Mensaje de error: "+ ex.getMessage());
        }
    }

    public static void tratarFichero() throws MiExcepcion{
        FileReader fr=null;
        try {
            File archivo = new File("E:\\Descargas\\Java\\Ejercicio2\\input.txt");
            fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            leerEscribirFichero(br);
        } catch (Exception e) {
            throw new MiExcepcion("Error:"+e.getMessage(),e.getCause());
        } finally {
            cerrarLeerFichero(fr);
        }
    }

    
    public static void leerEscribirFichero(BufferedReader br) throws IOException {
        FileWriter fichero = new FileWriter("E:\\Descargas\\Java\\Ejercicio2\\output.txt");
        PrintWriter pw = new PrintWriter(fichero);
        pw.println("------------------------------------------");
        pw.println("Resultado Conversión");
        pw.println("------------------------------------------");
        String linea;
        String resultado;
        while ((linea = br.readLine()) != null) {
            String vector[] = linea.split(" ");
            resultado = convertir_en_base(Integer.parseInt(vector[0]), Integer.parseInt(vector[1]));
            pw.println("El número "+vector[0]+" convertido en base "+vector[1]+" es "+resultado);
        }
        pw.println("------------------------------------------");
        cerrarEscribirFichero(pw);
    }
    
    
    public static void cerrarLeerFichero(FileReader fr) {
        try {
            if (null != fr) {
                fr.close();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    
    public static void cerrarEscribirFichero(PrintWriter pw) 
            throws IOException {
        try {
            if (null != pw) {
                pw.close();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }    
    
    public static String convertir_en_base(int numero, int base) {
        String[] pos = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"};
        String cadena = "";
        int modulo;
        while (numero > 0) {
            modulo = (numero % base);
            cadena += pos[modulo];
            numero = (numero / base);
        }
        StringBuilder builder = new StringBuilder(cadena);
        String resultado;
        resultado = builder.reverse().toString();

        return resultado;
    }
}