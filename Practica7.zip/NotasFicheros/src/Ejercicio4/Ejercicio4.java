package Ejercicio4;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author infor14
 */
public class Ejercicio4 {

    public static void main(String[] args) {
        try {
            tratarFichero();
            
        } catch (MiExcepcion ex) {
            System.out.println("Mensaje de error: "+ ex.getMessage());
        }catch (ClassNotFoundException e) {
            System.out.println("Mensaje de error: "+ e.getMessage());
        }
    }

    public static void tratarFichero() throws MiExcepcion, ClassNotFoundException{
        FileReader fr=null;
        try {
            File archivo = new File("C:\\Users\\infor14\\Documents\\prueba1\\alumnos.txt");
            fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            leerFichero(br);
        } catch (Exception e) {
            throw new MiExcepcion("Error:"+e.getMessage(),e.getCause());
        } finally {
            cerrarLeerFichero(fr);
        }
    }

    
    public static void leerFichero(BufferedReader br) throws IOException, ClassNotFoundException {
        String linea;
        while ((linea = br.readLine()) != null) {
            String vector[] = linea.split(" ");
            escribirFicheroNotas(vector);

        }
    }
    
    
    public static void cerrarLeerFichero(FileReader fr) {
        try {
            if (null != fr) {
                fr.close();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }


    public static void escribirFicheroNotas(String vector[]) throws IOException, ClassNotFoundException {

        /*FileWriter fichero = new FileWriter("E:\\Descargas\\Java\\Ejercicio3\\notas\\"
                + vector[0] + vector[1] + vector[2] + ".txt");
        PrintWriter pw = new PrintWriter(fichero); 
        */
        Alumno alumnoEscritura = new Alumno();
        Alumno alumnoLectura = new Alumno();
        
        alumnoEscritura.setNombre(vector[0]);
        alumnoEscritura.setApellido1(vector[1]);
        alumnoEscritura.setApellido2(vector[2]);
        alumnoEscritura.setLenguajeDeMarcas(vector[3]);
        alumnoEscritura.setProgramacion(vector[4]);
        alumnoEscritura.setEntornosDeDesarrollo(vector[5]);
        alumnoEscritura.setBaseDeDatos(vector[6]);
        alumnoEscritura.setSistemasInformáticos(vector[7]);
        alumnoEscritura.setFol(vector[8]);
       
        //Abrir fichero
        File f = new File("C:\\Users\\infor14\\Documents\\prueba1\\"
                + vector[0] + vector[1] + vector[2] + ".txt");

        //Crear stream de escritura para el fichero
        FileOutputStream fos = new FileOutputStream(f);

        //Crear stream para escribir el objeto
        ObjectOutputStream oos = new ObjectOutputStream(fos);


        //Escribir el objeto en el stream
        oos.writeObject(alumnoEscritura);
        
        cerraroos(oos);
        cerrarfos(fos);
        
        //Crear stream de lectura para el fichero
        FileInputStream fis = new FileInputStream( f );

        //Crear stream para leer el objeto
        ObjectInputStream ois = new ObjectInputStream( fis );

 
        alumnoLectura = (Alumno) ois.readObject();
   
        System.out.println(alumnoLectura.getApellido1());
        
        
        int convalidadas = 0;
        int aprobadas = 0;
        int suspendidas = 0;

        System.out.println("---------------------------------------------");
        System.out.println("Boletín de notas IES FBMOLL");
        System.out.println("---------------------------------------------");
        System.out.println("Alumno: " + alumnoLectura.getNombre()+alumnoLectura.getApellido1()+alumnoLectura.getApellido2());
        System.out.println("------------------------------------");
        System.out.println("Módulo                        Nota");
        System.out.println("--------------------------   -------");
        System.out.println("Lenguaje de marcas" + "\t \t" + alumnoLectura.getLenguajeDeMarcas());
        System.out.println("Programación" + "\t \t \t" + alumnoLectura.getProgramacion());
        System.out.println("Entornos de desarrollo" + "\t \t" + alumnoLectura.getEntornosDeDesarrollo());
        System.out.println("Base de datos" + "\t \t \t" + alumnoLectura.getBaseDeDatos());
        System.out.println("Sistemas informáticos" + "\t \t" + alumnoLectura.getSistemasInformáticos());
        System.out.println("FOL" + "\t \t \t \t" + alumnoLectura.getFol());
        for (int i = 3; i < vector.length; i++) {
            if (vector[i].equals("c-5")) {
                convalidadas++;
            } else if (Integer.parseInt(vector[i]) <= 5) {
                suspendidas++;
            } else {
                aprobadas++;
            }
        }
        System.out.println("------------------------------------------");
        System.out.println("Nº de módulos aprobados:\t"+aprobadas);
        System.out.println("Nº de módulos suspendidos:\t"+suspendidas);
        System.out.println("Nº de módulos convalidados:\t"+convalidadas);
        System.out.println("------------------------------------------");
        
        cerrarois(ois);
        cerrarfis(fis);

    }
    
    public static void cerraroos(ObjectOutputStream oos) 
            throws IOException {
        try {
            if (null != oos) {
                oos.close();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    } 
    
    public static void cerrarfos(FileOutputStream fos) 
            throws IOException {
        try {
            if (null != fos) {
                fos.close();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }    

    private static void cerrarois(ObjectInputStream ois)
            throws IOException {
        try {
            if (null != ois) {
                ois.close();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private static void cerrarfis(FileInputStream fis)
            throws IOException {
        try {
            if (null != fis) {
                fis.close();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

}

       
