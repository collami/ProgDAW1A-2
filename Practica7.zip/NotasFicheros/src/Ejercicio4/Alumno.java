/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio4;

import java.io.Serializable;

/**
 *
 * @author infor14
 */
public class Alumno implements Serializable{
    
    private  String nombre;
    private  String apellido1;
    private  String apellido2;
    private  String lenguajeDeMarcas;
    private  String programacion;
    private  String entornosDeDesarrollo;
    private  String baseDeDatos ;
    private  String sistemasInformáticos ;
    private  String fol;

    public Alumno(String nombre, String apellido1, String apellido2, String lenguajeDeMarcas, String programacion, String entornosDeDesarrollo, String baseDeDatos, String sistemasInformáticos, String fol) {
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.lenguajeDeMarcas = lenguajeDeMarcas;
        this.programacion = programacion;
        this.entornosDeDesarrollo = entornosDeDesarrollo;
        this.baseDeDatos = baseDeDatos;
        this.sistemasInformáticos = sistemasInformáticos;
        this.fol = fol;
    }

    public Alumno() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public String getLenguajeDeMarcas() {
        return lenguajeDeMarcas;
    }

    public void setLenguajeDeMarcas(String lenguajeDeMarcas) {
        this.lenguajeDeMarcas = lenguajeDeMarcas;
    }

    public String getProgramacion() {
        return programacion;
    }

    public void setProgramacion(String programacion) {
        this.programacion = programacion;
    }

    public String getEntornosDeDesarrollo() {
        return entornosDeDesarrollo;
    }

    public void setEntornosDeDesarrollo(String entornosDeDesarrollo) {
        this.entornosDeDesarrollo = entornosDeDesarrollo;
    }

    public String getBaseDeDatos() {
        return baseDeDatos;
    }

    public void setBaseDeDatos(String baseDeDatos) {
        this.baseDeDatos = baseDeDatos;
    }

    public String getSistemasInformáticos() {
        return sistemasInformáticos;
    }

    public void setSistemasInformáticos(String sistemasInformáticos) {
        this.sistemasInformáticos = sistemasInformáticos;
    }

    public String getFol() {
        return fol;
    }

    public void setFol(String fol) {
        this.fol = fol;
    }
    
       
    
    
}

