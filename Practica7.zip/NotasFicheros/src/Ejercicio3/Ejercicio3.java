
package Ejercicio3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author infor14
 */
public class Ejercicio3 {

    public static void main(String[] args) {
        try {
            tratarFichero();
        } catch (MiExcepcion ex) {
            System.out.println("Mensaje de error: "+ ex.getMessage());
        }
    }

    public static void tratarFichero() throws MiExcepcion{
        FileReader fr=null;
        try {
            File archivo = new File("E:\\Descargas\\Java\\Ejercicio3\\notas.txt");
            fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            leerFichero(br);
        } catch (Exception e) {
            throw new MiExcepcion("Error:"+e.getMessage(),e.getCause());
        } finally {
            cerrarLeerFichero(fr);
        }
    }

    
    public static void leerFichero(BufferedReader br) throws IOException {
        String linea;
        while ((linea = br.readLine()) != null) {
            String vector[] = linea.split(" ");
            escribirFicheroNotas(vector);

        }
    }
    
    
    public static void cerrarLeerFichero(FileReader fr) {
        try {
            if (null != fr) {
                fr.close();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }


    public static void escribirFicheroNotas(String vector[]) throws IOException{

        FileWriter fichero = new FileWriter("E:\\Descargas\\Java\\Ejercicio3\\notas\\"
                + vector[0] + vector[1] + vector[2] + ".txt");
        PrintWriter pw = new PrintWriter(fichero);        
        int convalidadas = 0;
        int aprobadas = 0;
        int suspendidas = 0;

        pw.println("---------------------------------------------");
        pw.println("Boletín de notas IES FBMOLL");
        pw.println("---------------------------------------------");
        pw.println("Alumno: " + vector[0] + " " + vector[1] + " " + vector[2]);
        pw.println("------------------------------------");
        pw.println("Módulo                        Nota");
        pw.println("--------------------------   -------");
        pw.println("Lenguaje de marcas" + "\t \t" + vector[3]);
        pw.println("Programación" + "\t \t \t" + vector[4]);
        pw.println("Entornos de desarrollo" + "\t \t" + vector[5]);
        pw.println("Base de datos" + "\t \t \t" + vector[6]);
        pw.println("Sistemas informáticos" + "\t \t" + vector[7]);
        pw.println("FOL" + "\t \t \t \t" + vector[8]);
        for (int i = 3; i < vector.length; i++) {
            if (vector[i].equals("c-5")) {
                convalidadas++;
            } else if (Integer.parseInt(vector[i]) <= 5) {
                suspendidas++;
            } else {
                aprobadas++;
            }
        }
        pw.println("------------------------------------------");
        pw.println("Nº de módulos aprobados:\t"+aprobadas);
        pw.println("Nº de módulos suspendidos:\t"+suspendidas);
        pw.println("Nº de módulos convalidados:\t"+convalidadas);
        pw.println("------------------------------------------");

        cerrarEscribirFichero(pw);
    }
    
    public static void cerrarEscribirFichero(PrintWriter pw) 
            throws IOException {
        try {
            if (null != pw) {
                pw.close();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }    
}
