package Ejercicio1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author infor14
 */
public class Ejercicio1 {

    public static void main(String[] args) {
        try {
            tratarFichero();
        } catch (MiExcepcion ex) {
            System.out.println("Mensaje de error: "+ ex.getMessage());
        }
    }

    public static void tratarFichero() throws MiExcepcion{
        FileReader fr=null;
        try {
            File archivo = new File("E:\\Descargas\\Java\\Ejercicio1\\personas.txt");
            fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            leerEscribirFichero(br);
        } catch (Exception e) {
            throw new MiExcepcion("Error:"+e.getMessage(),e.getCause());
        } finally {
            cerrarLeerFichero(fr);
        }
    }

    
    public static void leerEscribirFichero(BufferedReader br) throws IOException {
        FileWriter fichero = new FileWriter("E:\\Descargas\\Java\\Ejercicio1\\listado.txt");
        PrintWriter pw = new PrintWriter(fichero);
        pw.println("------------------");
        pw.println("Listado de Alumnos");
        pw.println("------------------");
        String linea;
        int contador=0;
        while ((linea = br.readLine()) != null) {
            String vector[] = linea.split(" ");
            if (Integer.parseInt(vector[2]) > 17){
                contador++;
                pw.println("----Alumno nº"+contador+"----");
                pw.println("Nombre: "+vector[0]);
                pw.println("Apellido: "+vector[1]);
                pw.println("Edad: "+vector[2]);
            }
        }
        pw.println("------------------");
        cerrarEscribirFichero(pw);
    }
    
    
    public static void cerrarLeerFichero(FileReader fr) {
        try {
            if (null != fr) {
                fr.close();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    
    public static void cerrarEscribirFichero(PrintWriter pw) 
            throws IOException {
        try {
            if (null != pw) {
                pw.close();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }    
}